import "dotenv/config";
import express from "express";
import helmet from "helmet";
import rateLimit from "express-rate-limit";
import OpenAI from "openai";

const app = express();
const PORT = process.env.PORT || 3000;
const MODEL = process.env.OPENAI_MODEL || "gpt-5.5";

app.use(helmet({ contentSecurityPolicy: false }));
app.use(express.json({ limit: "8mb" }));
app.use(express.static("public"));
app.use("/api/", rateLimit({ windowMs: 60_000, limit: 20 }));

app.get("/api/status", (_req, res) => {
  res.json({ ok: true, configured: Boolean(process.env.OPENAI_API_KEY), model: MODEL });
});

app.post("/api/chat", async (req, res) => {
  if (!process.env.OPENAI_API_KEY) {
    return res.status(503).json({ error: "Сервер ще не налаштований: додайте OPENAI_API_KEY у файл .env." });
  }
  const { messages, image } = req.body ?? {};
  if (!Array.isArray(messages) || messages.length === 0) {
    return res.status(400).json({ error: "Напишіть повідомлення." });
  }
  const clean = messages.slice(-16).map(m => ({
    role: m.role === "assistant" ? "assistant" : "user",
    content: String(m.content ?? "").slice(0, 8000)
  })).filter(m => m.content.trim());

  if (!clean.length) return res.status(400).json({ error: "Порожнє повідомлення." });

  const input = clean.map((m, i) => {
    if (m.role === "user" && i === clean.length - 1 && image && typeof image === "string" &&
        image.startsWith("data:image/") && image.length < 6_000_000) {
      return { role: "user", content: [
        { type: "input_text", text: m.content || "Опиши це зображення." },
        { type: "input_image", image_url: image }
      ]};
    }
    return m;
  });

  try {
    const client = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });
    const response = await client.responses.create({
      model: MODEL,
      instructions: "Ти GPT Pro — корисний, доброзичливий AI-помічник. Відповідай мовою користувача, пояснюй зрозуміло й чесно. Не стверджуй, що ти офіційний продукт OpenAI.",
      input
    });
    res.json({ reply: response.output_text || "Не вдалося отримати текстову відповідь." });
  } catch (err) {
    console.error("OpenAI API error:", err?.message || err);
    res.status(502).json({ error: "Не вдалося отримати відповідь від AI. Перевірте налаштування моделі, ключа та доступ до API." });
  }
});

app.listen(PORT, "0.0.0.0", () => {
  console.log(`GPT Pro працює: http://localhost:${PORT}`);
});